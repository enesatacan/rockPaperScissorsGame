import "./App.css";
import { useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import Welcome from "./components/Welcome";
import imagesData from "./components/images.json";

function App() {
  const [selectedMove, setSelectedMove] = useState(null);
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home imagesData={imagesData} />} />
          <Route
            path="/play"
            element={
              <Welcome
                selectedMove={selectedMove}
                setSelectedMove={setSelectedMove}
                imagesData={imagesData}
              />
            }
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
