import React, { useEffect, useState, useRef } from "react";
import { Grid, Stack, Typography, Button } from "@mui/material";
import Move from "./Move";
import drawSound from "./drawSound.mp3";
import "../App.css";

function Welcome({ selectedMove, setSelectedMove, imagesData }) {
  const [click, setClick] = useState(false);
  const [vs, setVs] = useState(false);
  const [count, setCount] = useState(3);
  const [randomIndex, setRandomIndex] = useState(0);
  const [userScore, setUserScore] = useState(0);
  const [computerScore, setComputerScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState(null);

  const audioRef = useRef(new Audio(drawSound));
  const playSound = () => {
    audioRef.current.play();
  };

  useEffect(() => {
    if (selectedMove && !gameOver) {
      setClick(true);
      setVs(true);
      const interval = setInterval(() => {
        setCount((prevCount) => {
          if (prevCount <= 0) {
            clearInterval(interval);
            return 0;
          }
          return prevCount - 1;
        });
      }, 1000);

      const timer = setTimeout(() => {
        const random = Math.floor(Math.random() * 3);
        setRandomIndex(random);
        const userChoiceIndex = imagesData.images.findIndex(
          (image) => image.url === selectedMove
        );

        if (random === userChoiceIndex) {
          playSound();
        } else {
          const winner = determineWinner(userChoiceIndex, random);
          if (winner === "user") {
            setUserScore((prevScore) => prevScore + 1);
          } else if (winner === "computer") {
            setComputerScore((prevScore) => prevScore + 1);
          }
        }

        setTimeout(() => {
          setVs(false);
          setClick(false);
          setCount(3);
          setSelectedMove(null);
        }, 1500);
      }, 3000);

      return () => {
        clearTimeout(timer);
        clearInterval(interval);
        setRandomIndex(0);
      };
    }
  }, [selectedMove, gameOver]);

  // Kazananı belirleyen fonksiyon
  const determineWinner = (userChoiceIndex, computerChoiceIndex) => {
    if (userChoiceIndex === computerChoiceIndex) return "draw";
    if (
      (userChoiceIndex === 0 && computerChoiceIndex === 2) || // rock beats scissors
      (userChoiceIndex === 1 && computerChoiceIndex === 0) || // paper beats rock
      (userChoiceIndex === 2 && computerChoiceIndex === 1) // scissors beats paper
    ) {
      return "user";
    } else {
      return "computer";
    }
  };

  // Oyunun sonucunu kontrol eden useEffect
  useEffect(() => {
    if (userScore === 3 || computerScore === 3) {
      setGameOver(true);
      setWinner(userScore === 3 ? "You" : "Computer");
    }
  }, [userScore, computerScore]);

  // Oyunu resetleyen fonksiyon
  const resetGame = () => {
    setUserScore(0);
    setComputerScore(0);
    setGameOver(false);
    setWinner(null);
  };

  return (
    <Stack marginTop={"200px"}>
      <Stack>
        {gameOver && (
          <Typography variant="h4" color="primary" align="center">
            Game Over! Winner: {winner}
          </Typography>
        )}

        <Grid container justifyContent={"center"} xs={12}>
          <Grid item xs={3}>
            <Typography variant="h5" mb={5}>
              Computer
              <Typography variant="h6">SCORE: {computerScore}</Typography>
            </Typography>
            {vs ? (
              <Typography variant="h6" fontWeight={"bold"}>
                <img
                  className={click ? "animate-bounce" : ""}
                  src={imagesData.images[randomIndex].url}
                  style={{
                    width: "350px",
                    height: "265px",
                    borderRadius: "10px",
                  }}
                  alt={imagesData.images[randomIndex].url}
                />
              </Typography>
            ) : (
              <Typography variant="h6">
                <img
                  src={imagesData.images[0].url}
                  style={{
                    width: "350px",
                    height: "265px",
                    borderRadius: "10px",
                  }}
                  alt={imagesData.images[0].url}
                />
              </Typography>
            )}
          </Grid>
          <Grid alignSelf={"center"} justifyContent={"center"} xs={3}>
            <Typography>
              {vs ? (
                <Typography variant="h6" fontWeight={"bold"}>
                  {count}
                </Typography>
              ) : (
                <Typography variant="h6"> VS </Typography>
              )}
            </Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography variant="h5" mb={5}>
              You
              <Typography variant="h6">SCORE: {userScore}</Typography>
            </Typography>
            {click ? (
              <img
                src={selectedMove}
                style={{
                  width: "350px",
                  height: "265px",
                  borderRadius: "10px",
                }}
                alt="Açıklama"
              />
            ) : (
              <img
                src={imagesData.images[0].url}
                style={{
                  width: "350px",
                  height: "265px",
                  borderRadius: "10px",
                }}
                alt="Açıklama"
              />
            )}
          </Grid>
        </Grid>
      </Stack>

      {gameOver ? (
        <Button variant="contained" color="primary" onClick={resetGame}>
          PLAY AGAIN
        </Button>
      ) : (
        <Move setSelectedMove={setSelectedMove} />
      )}
    </Stack>
  );
}

export default Welcome;
