import React from "react";
import { Button, Stack, Typography, Box } from "@mui/material";

import { useNavigate } from "react-router-dom";
function Home({ imagesData }) {
  const navigate = useNavigate();
  const start = () => {
    navigate("/play");
  };
  return (
    <Stack marginTop={"200px"}>
      <Stack spacing={5}>
        <Typography color={"primary"} variant="h4">
          Welcome to Rock Paper Scissors.
        </Typography>
        <Stack alignItems={"center"}>
          <img
            src={imagesData.mainImage.url}
            style={{
              width: "500px",
              borderRadius: "10px",
              contain: "center",
            }}
            alt="Açıklama"
          />
        </Stack>
        <Typography variant="body2">3 WINS...</Typography>
        <Typography variant="body2">GOOD LUCK</Typography>
        <Box>
          <Button variant="outlined" onClick={start}>
            Start
          </Button>
        </Box>
      </Stack>
    </Stack>
  );
}

export default Home;
