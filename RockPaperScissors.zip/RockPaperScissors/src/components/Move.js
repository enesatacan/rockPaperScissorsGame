import { Button, Typography, Box } from "@mui/material";
import imagesData from "./images.json";
import soundData from "./timerSound.mp3";
import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

function Move({ setSelectedMove }) {
  const navigate = useNavigate();
  const goBack = () => {
    navigate("/");
  };
  const audioRef = useRef(new Audio(soundData));
  const [disabled, setDisabled] = useState(false);

  const playSound = () => {
    audioRef.current.play();
  };

  const action = (url) => {
    playSound();
    setSelectedMove(url);
    setDisabled(true);
    console.log("Tıklandı:", url);

    setTimeout(() => {
      setDisabled(false);
    }, 5000);
  };

  return (
    <div>
      <Box my={5}>
        <Typography my={3} variant="body2">
          Please choose your next move...
        </Typography>
        {imagesData.images.map((image) => (
          <Button
            key={image.id}
            onClick={() => action(image.url)}
            disabled={disabled}
          >
            <img
              src={image.url}
              style={{ width: "60px", height: "60px", borderRadius: "50%" }}
              alt={image.description}
            />
          </Button>
        ))}
      </Box>
      <Button sx={{ marginTop: "50px" }} variant="outlined" onClick={goBack}>
        RESET
      </Button>
    </div>
  );
}

export default Move;
